# live — a lit window on who's here right now

A 3D globe where every logged-in person shows up as a warm point of light,
with a real DiceBear avatar and a real Supabase account behind it. New
joins get a soft expanding ripple. Click a light to open a profile panel.

**Zero-setup demo mode:** without a Supabase project connected, the app
runs on simulated presence (fake users joining/leaving on a timer) and a
local demo identity, so you can see and feel it immediately.

**Real mode:** once you add Supabase keys, real accounts (magic-link email
sign-in), real DiceBear avatars per user, and real live presence via
Supabase Realtime all switch on automatically — no code changes needed.

## Run it

```bash
npm install
npm run dev
```

Open http://localhost:3000. Without Supabase configured, you'll be dropped
straight into demo mode — the globe with ~9 simulated lights.

## Going live (real accounts + real presence)

1. Create a free Supabase project.
2. In the Supabase dashboard, enable **Email** auth with magic links
   (Authentication → Providers → Email — on by default on new projects).
3. Copy `.env.example` to `.env.local` and fill in your project URL + anon key:
   ```
   NEXT_PUBLIC_SUPABASE_URL=...
   NEXT_PUBLIC_SUPABASE_ANON_KEY=...
   ```
4. Restart the dev server. You'll now see a real sign-in screen — enter an
   email, get a magic link, and you're in. Presence is now tracked via
   Supabase Realtime instead of the simulator, and your avatar is a
   deterministic DiceBear image generated from your user ID.

No other code changes are required — `usePresence`, `useAuth`, and the
avatar/login UI all detect whether Supabase is configured and switch
behavior automatically.

## What's here

- `app/page.tsx` — top-level layout: wordmark, live count, sign-out, globe, profile panel
- `components/Globe.tsx` — react-globe.gl wrapper; presence dots + join ripples
- `components/ProfilePanel.tsx` — slide-in panel when you click a light, shows avatar
- `components/LoginGate.tsx` — magic-link email sign-in (or demo mode banner)
- `lib/usePresence.ts` — presence data source: real Supabase Realtime Presence, or simulated
- `lib/useAuth.ts` — auth state: real Supabase session, or a local demo identity
- `lib/avatar.ts` — DiceBear deterministic SVG avatar generation
- `lib/supabase.ts` — Supabase client, safely inert until env vars are set

## Deploying

Stock Next.js 14 app — deploys to Vercel with zero config:

```bash
npx vercel
```
Remember to set the same `NEXT_PUBLIC_SUPABASE_*` env vars in the Vercel
project settings.

## Design notes

Palette is deliberately twilight-indigo rather than pure black, and
presence reads as warm amber "lights turning on" rather than neon —
avoiding the generic near-black/neon-accent look. Type pairing is Fraunces
(display, a little literary/warm) + Sora (body) + IBM Plex Mono (for the
live counter and status labels, to give data a "readout" feel).

## Known limits to fix before any real launch

- Location is randomly assigned per session right now — replace with a
  user-chosen rough area or coarse IP lookup, and keep it city-level (not
  exact GPS) by design, for privacy
- No rate limiting on the presence channel or the auth email endpoint
- No moderation/reporting on the "say hi" interaction — needed before any
  real chat feature ships
- react-globe.gl performs well into the low thousands of concurrent points;
  if you outgrow that, the roadmap is to swap the rendering layer for
  deck.gl (see earlier discussion) without changing the data layer
