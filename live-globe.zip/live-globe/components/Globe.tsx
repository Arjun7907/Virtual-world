'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import dynamic from 'next/dynamic';
import type { PresenceUser } from '@/lib/usePresence';

// react-globe.gl touches `window` at import time — must be client-only, no SSR.
const ReactGlobe = dynamic(() => import('react-globe.gl'), { ssr: false });

const RIPPLE_LIFETIME_MS = 2600;

export default function Globe({
  users,
  onSelect,
}: {
  users: PresenceUser[];
  onSelect: (u: PresenceUser) => void;
}) {
  const globeRef = useRef<any>(null);
  const [dims, setDims] = useState({ width: 800, height: 800 });
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const resize = () =>
      setDims({ width: window.innerWidth, height: window.innerHeight });
    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, []);

  // Drives ripple fade + gentle recency glow — cheap tick, not per-frame.
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 120);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const g = globeRef.current;
    if (!g) return;
    g.controls().autoRotate = true;
    g.controls().autoRotateSpeed = 0.35;
    g.pointOfView({ lat: 12, lng: 20, altitude: 2.2 }, 0);
  }, []);

  const points = useMemo(
    () =>
      users.map((u) => {
        const age = now - u.joinedAt;
        const recency = Math.max(0, 1 - age / 20000); // brighter if joined recently
        return {
          ...u,
          size: 0.55,
          brightness: 0.55 + recency * 0.45,
        };
      }),
    [users, now]
  );

  // Ripple rings only for genuinely fresh joins, auto-expire.
  const rings = useMemo(
    () =>
      users
        .filter((u) => now - u.joinedAt < RIPPLE_LIFETIME_MS)
        .map((u) => ({ lat: u.lat, lng: u.lng, id: u.id })),
    [users, now]
  );

  return (
    <ReactGlobe
      ref={globeRef}
      width={dims.width}
      height={dims.height}
      backgroundColor="rgba(0,0,0,0)"
      globeImageUrl="//unpkg.com/three-globe/example/img/earth-night.jpg"
      bumpImageUrl="//unpkg.com/three-globe/example/img/earth-topology.png"
      atmosphereColor="#2e4066"
      atmosphereAltitude={0.18}
      pointsData={points}
      pointLat="lat"
      pointLng="lng"
      pointColor={(d: any) =>
        `rgba(242, 166, 90, ${d.brightness})`
      }
      pointAltitude={0.012}
      pointRadius="size"
      onPointClick={(p: any) => onSelect(p)}
      pointLabel={(d: any) => `${d.name} — ${d.status}`}
      ringsData={rings}
      ringLat="lat"
      ringLng="lng"
      ringColor={() => (t: number) => `rgba(242, 166, 90, ${1 - t})`}
      ringMaxRadius={4}
      ringPropagationSpeed={2.4}
      ringRepeatPeriod={RIPPLE_LIFETIME_MS}
    />
  );
}
