'use client';

import type { PresenceUser } from '@/lib/usePresence';

export default function ProfilePanel({
  user,
  onClose,
}: {
  user: PresenceUser | null;
  onClose: () => void;
}) {
  const open = !!user;

  return (
    <aside
      style={{
        position: 'fixed',
        top: 0,
        right: 0,
        height: '100%',
        width: 320,
        maxWidth: '85vw',
        background: 'var(--bg-panel)',
        borderLeft: '1px solid var(--line-cool)',
        backdropFilter: 'blur(10px)',
        transform: open ? 'translateX(0)' : 'translateX(100%)',
        transition: 'transform 320ms cubic-bezier(.2,.8,.2,1)',
        padding: '28px 24px',
        zIndex: 20,
      }}
    >
      {user && (
        <>
          <button
            onClick={onClose}
            aria-label="Close"
            style={{
              background: 'none',
              border: 'none',
              color: 'var(--text-muted)',
              fontFamily: 'var(--font-mono)',
              fontSize: 13,
              cursor: 'pointer',
              padding: 0,
              marginBottom: 24,
            }}
          >
            ← back to the globe
          </button>

          <img
            src={user.avatar}
            alt=""
            width={64}
            height={64}
            style={{
              borderRadius: '50%',
              marginBottom: 16,
              border: '2px solid var(--line-cool)',
            }}
          />

          <h2
            style={{
              fontFamily: 'var(--font-display)',
              fontWeight: 500,
              fontSize: 26,
              margin: '0 0 6px',
              color: 'var(--text-primary)',
            }}
          >
            Someone in {user.name}
          </h2>

          <p
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: 12,
              color: 'var(--accent-amber)',
              textTransform: 'uppercase',
              letterSpacing: '0.08em',
              margin: '0 0 20px',
            }}
          >
            {user.status}
          </p>

          <p
            style={{
              fontFamily: 'var(--font-body)',
              fontSize: 14,
              lineHeight: 1.6,
              color: 'var(--text-muted)',
              margin: '0 0 28px',
            }}
          >
            This is where a real profile — name, a line of bio, maybe a
            live status message — would live once accounts are wired up.
          </p>

          <button
            style={{
              width: '100%',
              padding: '12px 16px',
              background: 'var(--accent-amber)',
              border: 'none',
              borderRadius: 8,
              color: '#1a1206',
              fontFamily: 'var(--font-body)',
              fontWeight: 600,
              fontSize: 14,
              cursor: 'pointer',
            }}
          >
            Say hi 👋
          </button>
        </>
      )}
    </aside>
  );
}
