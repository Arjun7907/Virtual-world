'use client';

import { useState } from 'react';
import { useAuth } from '@/lib/useAuth';

export default function LoginGate({ children }: { children: React.ReactNode }) {
  const { identity, loading, signInWithEmail, isSupabaseConfigured } = useAuth();
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (loading) return null;

  // Demo mode (no Supabase configured yet) or already signed in — go straight in.
  if (identity) {
    return <>{children}</>;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const { error } = await signInWithEmail(email);
    if (error) setError(error);
    else setSent(true);
  }

  return (
    <main
      style={{
        height: '100vh',
        width: '100vw',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'radial-gradient(120% 100% at 50% 0%, var(--bg-mid) 0%, var(--bg-deep) 60%)',
      }}
    >
      <div style={{ width: 320, maxWidth: '85vw', textAlign: 'center' }}>
        <h1
          style={{
            fontFamily: 'var(--font-display)',
            fontStyle: 'italic',
            fontWeight: 500,
            fontSize: 28,
            color: 'var(--text-primary)',
            margin: '0 0 8px',
          }}
        >
          live
        </h1>
        <p
          style={{
            fontFamily: 'var(--font-body)',
            fontSize: 14,
            color: 'var(--text-muted)',
            margin: '0 0 28px',
          }}
        >
          Sign in to see who else is here right now.
        </p>

        {!isSupabaseConfigured && (
          <p
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: 11,
              color: 'var(--text-faint)',
              margin: '0 0 20px',
            }}
          >
            No Supabase project connected yet — running in demo mode.
          </p>
        )}

        {sent ? (
          <p
            style={{
              fontFamily: 'var(--font-body)',
              fontSize: 14,
              color: 'var(--accent-you)',
            }}
          >
            Check {email} for a sign-in link.
          </p>
        ) : (
          <form onSubmit={handleSubmit}>
            <input
              type="email"
              required
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={{
                width: '100%',
                padding: '11px 14px',
                borderRadius: 8,
                border: '1px solid var(--line-cool)',
                background: 'var(--bg-panel)',
                color: 'var(--text-primary)',
                fontFamily: 'var(--font-body)',
                fontSize: 14,
                marginBottom: 12,
              }}
            />
            <button
              type="submit"
              style={{
                width: '100%',
                padding: '12px 16px',
                background: 'var(--accent-amber)',
                border: 'none',
                borderRadius: 8,
                color: '#1a1206',
                fontFamily: 'var(--font-body)',
                fontWeight: 600,
                fontSize: 14,
                cursor: 'pointer',
              }}
            >
              Send sign-in link
            </button>
            {error && (
              <p
                style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: 12,
                  color: '#e0876a',
                  marginTop: 12,
                }}
              >
                {error}
              </p>
            )}
          </form>
        )}
      </div>
    </main>
  );
}
