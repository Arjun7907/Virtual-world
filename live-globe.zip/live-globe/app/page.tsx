'use client';

import { useState } from 'react';
import Globe from '@/components/Globe';
import ProfilePanel from '@/components/ProfilePanel';
import LoginGate from '@/components/LoginGate';
import { usePresence, type PresenceUser } from '@/lib/usePresence';
import { useAuth } from '@/lib/useAuth';

function LiveGlobe() {
  const { identity, signOut, isSupabaseConfigured } = useAuth();
  const users = usePresence(identity);
  const [selected, setSelected] = useState<PresenceUser | null>(null);

  return (
    <main style={{ position: 'relative', width: '100vw', height: '100vh' }}>
      <Globe users={users} onSelect={setSelected} />

      {/* Wordmark + live count — top-left, quiet */}
      <div
        style={{
          position: 'fixed',
          top: 28,
          left: 28,
          zIndex: 10,
        }}
      >
        <h1
          style={{
            fontFamily: 'var(--font-display)',
            fontStyle: 'italic',
            fontWeight: 500,
            fontSize: 22,
            margin: 0,
            color: 'var(--text-primary)',
          }}
        >
          live
        </h1>
        <p
          style={{
            fontFamily: 'var(--font-mono)',
            fontSize: 12,
            color: 'var(--text-muted)',
            margin: '4px 0 0',
          }}
        >
          <span style={{ color: 'var(--accent-amber)' }}>
            {String(users.length).padStart(2, '0')}
          </span>{' '}
          lights on right now
        </p>
      </div>

      {/* Account — top-right, quiet */}
      {identity && !identity.isDemo && (
        <button
          onClick={signOut}
          style={{
            position: 'fixed',
            top: 28,
            right: 28,
            zIndex: 10,
            background: 'none',
            border: 'none',
            fontFamily: 'var(--font-mono)',
            fontSize: 12,
            color: 'var(--text-faint)',
            cursor: 'pointer',
          }}
        >
          sign out
        </button>
      )}
      {identity?.isDemo && !isSupabaseConfigured && (
        <div
          style={{
            position: 'fixed',
            top: 28,
            right: 28,
            zIndex: 10,
            fontFamily: 'var(--font-mono)',
            fontSize: 11,
            color: 'var(--text-faint)',
            textAlign: 'right',
            maxWidth: 200,
          }}
        >
          demo mode — connect Supabase to go live
        </div>
      )}

      {/* Instruction — bottom-center, quiet */}
      <div
        style={{
          position: 'fixed',
          bottom: 24,
          left: '50%',
          transform: 'translateX(-50%)',
          zIndex: 10,
          fontFamily: 'var(--font-mono)',
          fontSize: 12,
          color: 'var(--text-faint)',
          pointerEvents: 'none',
        }}
      >
        click a light to say hi
      </div>

      <ProfilePanel user={selected} onClose={() => setSelected(null)} />
    </main>
  );
}

export default function Home() {
  return (
    <LoginGate>
      <LiveGlobe />
    </LoginGate>
  );
}
