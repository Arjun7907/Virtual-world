import { createClient } from '@supabase/supabase-js';

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

export const isSupabaseConfigured = Boolean(url && key);

// Only created when real env vars are set. When not configured, the app
// falls back to simulated presence and a "demo" local identity so it's
// still fully explorable with zero setup.
export const supabase = isSupabaseConfigured ? createClient(url!, key!) : null;
