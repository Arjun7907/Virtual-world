'use client';

import { useEffect, useState } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';

export type Identity = {
  id: string;
  email: string | null;
  isDemo: boolean;
};

const DEMO_ID_KEY = 'live-globe-demo-id';

function getOrCreateDemoId(): string {
  if (typeof window === 'undefined') return 'demo';
  let id = localStorage.getItem(DEMO_ID_KEY);
  if (!id) {
    id = `demo-${Math.random().toString(36).slice(2, 10)}`;
    localStorage.setItem(DEMO_ID_KEY, id);
  }
  return id;
}

export function useAuth() {
  const [identity, setIdentity] = useState<Identity | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isSupabaseConfigured || !supabase) {
      // No Supabase project configured yet — use a stable local demo
      // identity so the app is fully explorable with zero setup.
      setIdentity({ id: getOrCreateDemoId(), email: null, isDemo: true });
      setLoading(false);
      return;
    }

    supabase.auth.getSession().then(({ data }) => {
      const user = data.session?.user;
      setIdentity(
        user ? { id: user.id, email: user.email ?? null, isDemo: false } : null
      );
      setLoading(false);
    });

    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      const user = session?.user;
      setIdentity(
        user ? { id: user.id, email: user.email ?? null, isDemo: false } : null
      );
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  async function signInWithEmail(email: string) {
    if (!supabase) return { error: 'Supabase is not configured yet.' };
    const { error } = await supabase.auth.signInWithOtp({ email });
    return { error: error?.message ?? null };
  }

  async function signOut() {
    if (supabase) await supabase.auth.signOut();
  }

  return { identity, loading, signInWithEmail, signOut, isSupabaseConfigured };
}
