import { createAvatar } from '@dicebear/core';
import { thumbs } from '@dicebear/collection';

/**
 * Deterministic SVG avatar (data URI) from any seed — same seed always
 * produces the same avatar, so a user's avatar stays stable across visits
 * without ever storing or uploading a photo.
 */
export function avatarDataUri(seed: string): string {
  const avatar = createAvatar(thumbs, {
    seed,
    backgroundColor: ['f2a65a', '7fd8c6', '8891a6'],
    scale: 85,
  });
  return avatar.toDataUri();
}
