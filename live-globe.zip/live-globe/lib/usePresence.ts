'use client';

import { useEffect, useRef, useState } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { avatarDataUri } from '@/lib/avatar';
import type { Identity } from '@/lib/useAuth';

export type PresenceUser = {
  id: string;
  name: string;
  avatar: string; // data URI
  status: string;
  lat: number;
  lng: number;
  joinedAt: number; // ms epoch — used to fade the "just joined" ripple
};

// Rough city anchors — presence is deliberately city-level, never exact
// GPS, for privacy. Real deployments should ask the user to pick a rough
// area or use a coarse IP-based lookup, not precise geolocation.
const CITY_ANCHORS: { name: string; lat: number; lng: number }[] = [
  { name: 'Dubai', lat: 25.2, lng: 55.3 },
  { name: 'London', lat: 51.5, lng: -0.1 },
  { name: 'New York', lat: 40.7, lng: -74.0 },
  { name: 'São Paulo', lat: -23.6, lng: -46.6 },
  { name: 'Lagos', lat: 6.5, lng: 3.4 },
  { name: 'Mumbai', lat: 19.1, lng: 72.9 },
  { name: 'Singapore', lat: 1.35, lng: 103.8 },
  { name: 'Tokyo', lat: 35.7, lng: 139.7 },
  { name: 'Sydney', lat: -33.9, lng: 151.2 },
  { name: 'Cairo', lat: 30.0, lng: 31.2 },
  { name: 'Nairobi', lat: -1.3, lng: 36.8 },
  { name: 'Toronto', lat: 43.7, lng: -79.4 },
  { name: 'Berlin', lat: 52.5, lng: 13.4 },
  { name: 'Jakarta', lat: -6.2, lng: 106.8 },
  { name: 'Seoul', lat: 37.6, lng: 127.0 },
];

const STATUSES = ['just arrived', 'up for a chat', 'heads down', 'exploring', 'online'];

function randomSimUser(): PresenceUser {
  const city = CITY_ANCHORS[Math.floor(Math.random() * CITY_ANCHORS.length)];
  const jitter = () => (Math.random() - 0.5) * 3;
  const seed = `${city.name}-${Math.random().toString(36).slice(2, 8)}`;
  return {
    id: seed,
    name: city.name,
    avatar: avatarDataUri(seed),
    status: STATUSES[Math.floor(Math.random() * STATUSES.length)],
    lat: city.lat + jitter(),
    lng: city.lng + jitter(),
    joinedAt: Date.now(),
  };
}

/**
 * Simulated presence — used when no Supabase project is configured yet,
 * so the app is fully explorable with zero setup.
 */
function useSimulatedPresence() {
  const [users, setUsers] = useState<PresenceUser[]>(() =>
    Array.from({ length: 9 }, randomSimUser)
  );

  useEffect(() => {
    const joinInterval = setInterval(() => {
      setUsers((prev) => (prev.length > 22 ? prev : [...prev, randomSimUser()]));
    }, 4200);

    const leaveInterval = setInterval(() => {
      setUsers((prev) => {
        if (prev.length < 6) return prev;
        const idx = Math.floor(Math.random() * prev.length);
        return prev.filter((_, i) => i !== idx);
      });
    }, 9000);

    return () => {
      clearInterval(joinInterval);
      clearInterval(leaveInterval);
    };
  }, []);

  return users;
}

/**
 * Real Supabase Realtime Presence — tracks the signed-in user's own
 * position/status and syncs everyone else's live. City-level position only.
 */
function useSupabasePresence(identity: Identity | null) {
  const [users, setUsers] = useState<PresenceUser[]>([]);
  const channelRef = useRef<ReturnType<NonNullable<typeof supabase>['channel']> | null>(null);

  useEffect(() => {
    if (!supabase || !identity) return;

    const city = CITY_ANCHORS[Math.floor(Math.random() * CITY_ANCHORS.length)];
    const self: Omit<PresenceUser, 'id' | 'joinedAt'> = {
      name: city.name,
      avatar: avatarDataUri(identity.id),
      status: 'online',
      lat: city.lat,
      lng: city.lng,
    };

    const channel = supabase.channel('live-presence', {
      config: { presence: { key: identity.id } },
    });
    channelRef.current = channel;

    function syncFromChannel() {
      const state = channel.presenceState<PresenceUser>();
      const flat: PresenceUser[] = Object.entries(state).map(([id, metas]) => {
        const meta = metas[0] as unknown as PresenceUser;
        return { ...meta, id };
      });
      setUsers(flat);
    }

    channel
      .on('presence', { event: 'sync' }, syncFromChannel)
      .subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          await channel.track({ ...self, joinedAt: Date.now() });
        }
      });

    return () => {
      channel.unsubscribe();
    };
  }, [identity]);

  return users;
}

export function usePresence(identity: Identity | null) {
  const simulated = useSimulatedPresence();
  const real = useSupabasePresence(identity);
  return isSupabaseConfigured ? real : simulated;
}
